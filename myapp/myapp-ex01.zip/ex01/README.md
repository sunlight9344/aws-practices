# AWS CloudFormation Template Example: myapp

### 1. Node Application (PROFILE: dev)
### 2. Local MySQL
### 3. Local Storing
