const config = {
    port: 8080,
    uploadTemp: "store-temporary"
}

module.exports = config;